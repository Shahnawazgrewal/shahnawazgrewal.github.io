---
layout: page
title: About
permalink: /about/
---
I am second PhD student in computer science at The Applied Recognition Technology Laboratory (Arte-Lab), University of Insubria Italy with research interests in multi-modal fusion under supervisor of Prof. Ignazio Gallo. I have succesfully completed master program from Technical University of Eindhoven, Netherlands and Technical Univesity of Berlin, Germany under European Institute of Innovation and Technology Digital Master program.
